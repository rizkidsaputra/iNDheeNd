# NDN IFA Development Dataset

Dataset development PoC 11C: enam run eligible, masing-masing satu untuk M0/M1 × B0/B1/A1. Ini bukan final unseen test set dan belum memenuhi target tiga replikasi per skenario.

| Skenario | Run | Strata protokol |
|---|---|---|
| M0 B0 | safety150_b0_m0_v8 | v8, safety pilot historis |
| M0 B1 | safety150_b1_m0_v8 | v8, safety pilot historis |
| M0 A1 | safety150_a1_m0_v8 | v8, safety pilot historis |
| M1 B0 | m1dev_v14_r01_b0 | v14, eligible menurut v14; bukan replikasi v16 |
| M1 B1 | m1dev_v16_r01_b1 | v16, eligible_clean |
| M1 A1 | m1dev_v16_r02_a1 | v16, eligible_clean |

Isi utama ada di `dataset_development/`: `m0/` dan `m1/` untuk metadata run; `telemetry_collector/` untuk laporan yang diterima dan availability/Mask/Age; `telemetry_source_audit/` untuk audit laporan yang dihasilkan; `ground_truth/`, `workload/`, `diagnostics/`, `topology/`, `qa/`, dan `manifest/` untuk label, event aplikasi, kesehatan, topologi, quality flags, indeks, serta checksum. `protocols/v16_frozen_protocol.json` adalah konfigurasi v16 yang dibekukan. Timestamp dan boot ID asli dipertahankan; monotonic timestamp antar-boot tidak boleh dibandingkan langsung.

Mask/Age dihitung hanya dari laporan collector yang sudah tiba on-time pada waktu keputusan. Source-generated telemetry adalah bahan audit, bukan pengisi fitur yang hilang. Late dan not-received adalah kategori berbeda.

`manifest/run_index.jsonl` hanya berisi enam run eligible. `manifest/attempt_index.jsonl` juga mencatat B0 v16 r03 yang gagal sebagai riwayat percobaan; tidak ada fitur, telemetry, atau raw evidence run gagal itu yang dimasukkan sebagai run eligible. Path raw archive di metadata adalah rujukan asal dan tidak berarti arsip raw tersebut ada di ZIP ini.

Dataset ini mencampur protokol v8, v14, dan v16. Gunakan strata protokol dan quality flags saat analisis; jangan menyebut enam run tersebut sebagai replikasi homogen. Arsip sumber terverifikasi SHA-256: `9cfbf17f1e77a53eb61760078c552c405e914ecf6e52be4ab8209f50d7f745b6`. File `dataset_development/manifest/SHA256SUMS` memuat hash 90 file payload aslinya.
